@echo off
:: VideoRec Launcher - runs the app without leaving a terminal window open
:: Double-click this file to launch VideoRec

cd /d "%~dp0"

:: Check if node_modules exists (first run setup)
if not exist "node_modules\" (
    echo Installing VideoRec dependencies, please wait...
    npm install --silent
)

:: Launch Electron app without a visible command prompt window
:: Using start /B to detach from the console
start "" /B npx electron . >nul 2>&1
exit
