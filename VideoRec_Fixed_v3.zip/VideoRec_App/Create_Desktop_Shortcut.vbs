' Run this ONCE to create a Desktop shortcut that works correctly
Set fso = CreateObject("Scripting.FileSystemObject")
Set WshShell = CreateObject("WScript.Shell")

Dim appDir
appDir = fso.GetParentFolderName(WScript.ScriptFullName)

Dim desktopPath
desktopPath = WshShell.SpecialFolders("Desktop")

' Create shortcut on Desktop pointing to VideoRec.vbs in the app folder
Dim shortcut
Set shortcut = WshShell.CreateShortcut(desktopPath & "\VideoRec.lnk")
shortcut.TargetPath = appDir & "\VideoRec.vbs"
shortcut.WorkingDirectory = appDir
shortcut.Description = "VideoRec Screen Recorder"
shortcut.Save

MsgBox "Done! VideoRec shortcut created on your Desktop." & vbCrLf & vbCrLf & "Double-click the VideoRec icon on your Desktop to launch.", vbInformation, "VideoRec"
